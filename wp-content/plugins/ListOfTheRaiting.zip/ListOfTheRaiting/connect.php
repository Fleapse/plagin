<?php
require($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');
global $wpdb;


?>